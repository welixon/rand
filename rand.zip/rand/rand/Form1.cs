﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace rand
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bGenerate_Click(object sender, EventArgs e)
        {
            int minLength = 4;
            int maxLength = 16;

            string charAvailable = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

            StringBuilder password = new StringBuilder();
            Random rdm = new Random();

            int passwordLength = rdm.Next(minLength, maxLength + 1);

            while (passwordLength-- > 0)
                password.Append(charAvailable[rdm.Next(charAvailable.Length)]);
            
            tbPassword.Text = password.ToString();
        }
    }
}
